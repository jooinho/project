package com.example.dao;

public interface MysqlDAO {
	public String getTime();
}
