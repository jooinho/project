package com.example.service;


import com.example.domain.SellVO;

public interface TradeService {
	public void insert(SellVO vo);
	public void sinsert(SellVO vo);
}
